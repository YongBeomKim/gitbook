import joblib, os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler

import torch
import torch.nn as nn  
import seaborn as sns


## Sklearn Model Loading and Running
### ==================================================================================

# defined Functions
def loading_dataset(file):
    table = pd.read_csv(file)
    table['time/temperature'] = table['fin time'] / table['fin bean tem']
    table = table.sort_values('time/temperature').reset_index(drop=True)
    return table


# loading the Model
def loading_model(file1, file2):
    model_ph   = joblib.load(file1)
    model_brix = joblib.load(file2)
    print(f"feacture : {model_brix.coef_[0][0]}\nbias : {model_brix.intercept_[0]}" )
    print(model_brix, model_ph)
    return model_brix, model_ph


# Ph 및 Brix 모델의 예측과 활용
def predict_model(table, model_ph, model_brix):
    
    # ph 의 예측 모델의 활용
    ## ================================================
    ## PreProcessing The DataSet
    table_one = table.loc[:, ['time/temperature', 'ph']]
    x = table_one.iloc[:,0].values.astype(float)
    y = table_one.iloc[:,1].values.astype(float)
    model_ph.fit(x.reshape(-1, 1), y.reshape(-1, 1))

    # predict model Running
    ph_pred = model_ph.predict(x.reshape(-1,1))

    # Sorting predicted values with respect to predictor
    sorted_zip = sorted(zip(x, ph_pred))
    x_poly, poly_pred = zip(*sorted_zip)

    # R2 Score Print
    r2_sore_value = r2_score(y, poly_pred)
    print(f"R2 Score : {r2_sore_value}")

    # MSE, RMSE Print
    MSE = mean_squared_error(y, poly_pred)
    print(f"MSE Score : {MSE}")
    print(f"RMSE Score : {MSE**0.5}")

    # plotting predictions
    plt.figure(figsize=(10,6))
    plt.scatter(x, y, s=15)
    plt.plot(x_poly, poly_pred, color='r', label='Polynomial Regression')
    plt.xlabel('time/temperature', fontsize=16)
    plt.ylabel('ph', fontsize=16)
    plt.legend()
    plt.show()
    
    # Brix 모델의 예측과 출력
    # 가열정도와 Ph 값 관계 찾는 회귀함수
    table_two = table.loc[:, ['ph','brix']]
    x = table_two.iloc[:,0].values.astype(float)
    y = table_two.iloc[:,1].values.astype(float)

    # 학습한 모델을 사용하여 예측하기
    y_pred = model_brix.predict(x.reshape(-1,1))

    r2_sore_value = r2_score(y, y_pred.T[0])
    print(f"R2 Score : {r2_sore_value}")

    MSE = mean_squared_error(y, y_pred.T[0])
    print(f"MSE Score : {MSE}")
    print(f"RMSE Score : {MSE**0.5}")

    # Graph
    plt.figure(figsize=(8,8))
    plt.scatter(x, y, s=15)
    plt.plot(x, y_pred.T[0], color='r', label='linear Regression')
    plt.xlabel('brix',fontsize=16)
    plt.ylabel('ph',fontsize=16)
    plt.legend()
    plt.show()
    
    # 데이터 결과값 저장 및 출력
    table['ph_predict'] = ph_pred
    table['brix_predict'] = y_pred.T[0]
    table['tds_predict'] = table['brix_predict'] * 0.8
    return table



## Pytorch LSTM Model Loading and Running
### ==================================================================================

def load_excel(file):
    data_raw = pd.read_excel(file)
    data_raw = data_raw.loc[:, ["air","gas","gasgap","gram","bean"]]
    data = data_raw[ 
        (data_raw['bean'] != 0) & (data_raw['gasgap'] <= 40) ].reset_index(drop=True)
    price = data[['bean']]

    scaler = MinMaxScaler(feature_range=(-1, 1))
    price.loc[:,'bean'] = scaler.fit_transform(price['bean'].values.reshape(-1,1))
    return price , data, scaler


def split_data(stock, lookback=60):
    data_raw = stock.to_numpy() # convert to numpy array
    data = []
    
    # create all possible sequences of length seq_len
    for index in range(len(data_raw) - lookback): 
        data.append(data_raw[index: index + lookback])
    
    data = np.array(data);
    X = data[:, :-1, :]
    y = data[:,  -1, :]
    X = torch.from_numpy(X).type(torch.Tensor)
    y = torch.from_numpy(y).type(torch.Tensor)
    #test_set_size = int(np.round(0.2*data.shape[0]));
    #train_set_size = data.shape[0] - (test_set_size);
    #x_train = data[:train_set_size,:-1,:]
    #y _train = data[:train_set_size,-1,:]
    #x_test  = data[train_set_size:,:-1]
    #y_test  = data[train_set_size:,-1,:]
    return X, y
    #return [x_train, y_train, x_test, y_test]
    

    


def r2_score_and_save_csv(y, y_pred, scaler, data, lookback=60):
    #data = data.iloc[lookback:,:]
    original = pd.DataFrame(scaler.inverse_transform(y.detach().numpy()))
    predict = pd.DataFrame(scaler.inverse_transform(y_pred.detach().numpy()))
    r2_value = r2_score(original, predict)
    print(f"r2_score is : {r2_value}")
    # print(len(data), len(y))
    data_zero = [0] * lookback
    data_original = data_zero + original[0].to_list()
    data_predict = data_zero + predict[0].to_list()

    # data['original'] = data_original
    data['bean_lstm'] = data_predict
#     for index in range(len(data)-lookback):
#         data.loc[index + lookback, 'original'] = original[0].to_list()[index]
#         data.loc[index + lookback, 'lstm'] = predict[0].to_list()[index ]
    return data, predict, original
    
    
 
def plot_data(original, predict):
    sns.set_style("darkgrid")    
    plt.rcParams['figure.figsize'] = (18.0, 3.0)
    ax = sns.lineplot(x = original.index, y = original[0], label="Raw Data", color='royalblue')
    ax = sns.lineplot(x = predict.index, y = predict[0], label="Training Prediction (LSTM)", color='tomato')
    ax.set_title('Bean Temperature', size = 14, fontweight='bold')
    ax.set_xlabel("Rosting Time", size = 14)
    ax.set_ylabel("Bean Temperature", size = 14)
    # ax.set_xticklabels('', size=10)

    


def lstm_pytorch_model(file):

    # 모델의 파라미터 정의하기
    input_dim = 1
    hidden_dim = 32
    num_layers = 2
    output_dim = 1

    # LSTM Pytorch Model 
    class LSTM(nn.Module):
        def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
            super(LSTM, self).__init__()
            self.hidden_dim = hidden_dim
            self.num_layers = num_layers

            self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
            self.fc = nn.Linear(hidden_dim, output_dim)

        def forward(self, x):
            h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_()
            c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_()
            out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
            out = self.fc(out[:, -1, :]) 
            return out
    
    # 학습을 위한 DataSet 에 맞도록 Model 의 파라미터 추가 정의하기 
    model = LSTM(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, num_layers=num_layers)
    model.load_state_dict(torch.load(file))
    return model  # model.eval()
